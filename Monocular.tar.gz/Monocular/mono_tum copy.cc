#include <iostream>
#include <algorithm>
#include <fstream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include "Converter.h"

#include <System.h>
#include <sys/time.h>

using namespace cv;
using namespace std;
using namespace ORB_SLAM2;

// void LoadImages(const string &strFile, vector<string> &vstrImageFilenames,
//                 vector<double> &vTimestamps);

long GetCurrentTime(void);
int main(int argc, char **argv)
{
    // VideoCapture inputVideo(0);
    // //inputVideo.set(CV_CAP_PROP_FRAME_WIDTH, 320);
    // //inputVideo.set(CV_CAP_PROP_FRAME_HEIGHT, 240);
    // if (!inputVideo.isOpened())
    // {
    //     cout << "Could not open the input video " << endl;
    //     return -1;
    // }
    // else
    // {
    //     Mat frame;
    //     inputVideo >> frame;
    //     if (frame.empty())
    //     {
    //         cout << "frame empty" << endl;
    //         return -1;
    //     }
    //     imwrite("cvImg.jpg", frame);
    //     return -1;  
    // }

    if (argc != 4)
    {
        cerr << endl 
            << "Usage: ./mono_tum path_to_vocabulary path_to_settings path_to_sequence" << endl;
        return 1;
    }

    // Retrieve paths to images
    // vector<string> vstrImageFilenames;
    // vector<double> vTimestamps;
    // string strFile = string(argv[3]) + "/rgb.txt";
    // LoadImages(strFile, vstrImageFilenames, vTimestamps);

    // int nImages = vstrImageFilenames.size();

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM2::System SLAM(argv[1],argv[2],ORB_SLAM2::System::MONOCULAR, false);

    // Vector for tracking time statistics
    // vector<float> vTimesTrack;
    // vTimesTrack.resize(nImages);

    cout << endl << "-------mono v1.7-------" << endl;
    cout << "Start processing sequence ..." << endl;
    // cout << "Images in the sequence: " << nImages << endl << endl;  
    // cout << "Open Cam" << nImages << endl
    //      << endl;

    VideoCapture inputVideo(0);
    // Main loop
    cv::Mat im;
    inputVideo >> im;
    // for(int ni=0; ni<nImages; ni++)
    int iCount = 0;
    while (1)
    {
        // Read image from file
        // im = cv::imread(string(argv[3])+"/"+vstrImageFilenames[ni],CV_LOAD_IMAGE_UNCHANGED);
        inputVideo >> im;
        // double tframe = vTimestamps[ni];

        // printf("p d tframe is [%f]\n", tframe);

        double tframe = GetCurrentTime();

        // printf("p d GetCurrentTime is [%f]\n", tframe);

        // printf("p d tframe is [%d]\n", tframe);
        // cout << "c d tframe is [" << tframe << "]" << endl;
        // cout << "c i tframe is [" << (int)tframe << "]" << endl;

        if (im.empty())
        {
            // cerr << endl << "Failed to load image at: "
            //      << string(argv[3]) << "/" << vstrImageFilenames[ni] << endl;
            return 1;
        }

        // #ifdef COMPILEDWITHC11
        //         std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();
        // #else
        //         std::chrono::monotonic_clock::time_point t1 = std::chrono::monotonic_clock::now();
        // #endif

        // Pass the image to the SLAM system

        Mat Tcw = SLAM.TrackMonocular(im, tframe);
        cout << iCount << endl;
        iCount++;
        // cout << Tcw << endl;
        // cout << Tcw.cols << " " << Tcw.rows << endl;
        if ((Tcw.cols == 4) && (Tcw.rows == 4))
        {
            Mat Rwc = Tcw.rowRange(0, 3).colRange(0, 3).t();
            Mat Twc = -Rwc * Tcw.rowRange(0, 3).col(3);
            vector<float> q = Converter::toQuaternion(Rwc);
            // cout << "------------------" << endl;
            // cout << Twc << endl;
            cout << "X " << Twc.at<float>(0, 0) * 100 << endl;
            cout << "Y " << Twc.at<float>(1, 0) * 100 << endl;
            cout << "Z " << Twc.at<float>(2, 0) * 100 << endl;
            // QuaternionToeularangle(q[3], q[2], q[1], q[0]);
            cout << "------------------" << endl;
        }

// #ifdef COMPILEDWITHC11
//         std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
// #else
//         std::chrono::monotonic_clock::time_point t2 = std::chrono::monotonic_clock::now();
// #endif

        // double ttrack= std::chrono::duration_cast<std::chrono::duration<double> >(t2 - t1).count();

        // vTimesTrack[ni]=ttrack;

        // Wait to load the next frame
        // double T=0;
        // if(ni<nImages-1)
        //     T = vTimestamps[ni+1]-tframe;
        // else if(ni>0)
        //     T = tframe-vTimestamps[ni-1];

        // if(ttrack<T)
        //     usleep((T-ttrack)*1e6);
    }

    // Stop all threads
    SLAM.Shutdown();

    // Tracking time statistics
    // sort(vTimesTrack.begin(),vTimesTrack.end());
    // float totaltime = 0;
    // for(int ni=0; ni<nImages; ni++)
    // {
    //     totaltime+=vTimesTrack[ni];
    // }
    // cout << "-------" << endl << endl;
    // cout << "median tracking time: " << vTimesTrack[nImages/2] << endl;
    // cout << "mean tracking time: " << totaltime/nImages << endl;

    // Save camera trajectory
    // SLAM.SaveKeyFrameTrajectoryTUM("KeyFrameTrajectory.txt");

    return 0;
}

long GetCurrentTime(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

// void LoadImages(const string &strFile, vector<string> &vstrImageFilenames, vector<double> &vTimestamps)
// {
//     ifstream f;
//     f.open(strFile.c_str());
//     // skip first three lines
//     string s0;
//     getline(f,s0);
//     getline(f,s0);
//     getline(f,s0);
//     while(!f.eof())
//     {
//         string s;
//         getline(f,s);
//         if(!s.empty())
//         {
//             stringstream ss;
//             ss << s;
//             double t;
//             string sRGB;
//             ss >> t;
//             vTimestamps.push_back(t);
//             ss >> sRGB;
//             vstrImageFilenames.push_back(sRGB);
//         }
//     }
// }
