#include <iostream>
#include <algorithm>
#include <fstream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include "Converter.h"

#include <System.h>
#include <sys/time.h>

#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <log.h>
#include <app_uart.h>
#include <ConvertCP.h>

#include <sstream>
#include <string>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define APP_UART "/dev/ttyS2"
#define SOCKET_FILE "SocketConfig"
#define DEVICE_LED_UART_BAUD_RATE 115200

static int livUartFd;
static int livSocketFd;

using namespace cv;
using namespace std;
using namespace ORB_SLAM2;

// void LoadImages(const string &strFile, vector<string> &vstrImageFilenames,
//                 vector<double> &vTimestamps);

#define CV_IMG_COUNT 0

long GetCurrentTime(void);
void InitTCP(void);
void InitUart(void);

void TestUart(void)
{
    char buf[512];
    char data_str[4] = {'a', 'b', 'c', 'd'};
    int i;
    
    log_info(">====Welcome to Uart Test=====<");
    cout << "Uart :" << APP_UART << endl;

    livUartFd = app_uart_open(livUartFd, APP_UART);
    app_uart_Init(livUartFd, DEVICE_LED_UART_BAUD_RATE, 0, 8, 1, 'N');

    while (1)
    {
        app_uart_write(livUartFd, data_str, 4);
        usleep(100 * 1000);
        app_uart_read(livUartFd, buf, sizeof(buf), 2000);
        for (i = 0; i < 16; i++)
            printf("data = %x \r\n", buf[i]);
    }
}


void TestTCP(void)
{
    InitTCP();

    while(1)
    {
        char writeData[] = {'h', 'e', 'l', 'l', 'o', '\n'};
        int writelen = sizeof(writeData) / sizeof(unsigned char);
        write(livSocketFd, writeData, writelen);
        usleep(1000 * 1000);
    }
}

int main(int argc, char **argv)
{
    cout << endl
         << "-------mono v1.8-------" << endl;

    InitUart();
    InitTCP();

    // urat_test();

    // TestTCP();

    if (argc != 4)
    {
        cerr << endl
             << "Usage: ./mono_tum path_to_vocabulary path_to_settings path_to_sequence" << endl;
        return 1;
    }

    // Create SLAM system. It initializes all system threads and gets ready to process frames.
    ORB_SLAM2::System SLAM(argv[1], argv[2], ORB_SLAM2::System::MONOCULAR, false);

    cout << endl
         << "CV_IMG_COUNT " << CV_IMG_COUNT << endl;
    int iCount = 0;

    // Main loop
    cv::Mat im;

#if CV_IMG_COUNT
    for (int i = 0; i < CV_IMG_COUNT; i++)
#else
    VideoCapture inputVideo(0);
    while (1)
#endif
    {
        // cout << iCount << endl;
        iCount++;
        // Read image from file
        
        ostringstream strPath;
        strPath << "/tmp/cvImg" << iCount << ".jpg";
        cout << "img Path " << strPath.str() << endl;

#if CV_IMG_COUNT
        im = imread(strPath.str());
#else
        inputVideo >> im;
#endif

        double tframe = GetCurrentTime();

        if (im.empty())
        {
            cout << "Failed to load image" << endl;
            return 1;
        }

        // Pass the image to the SLAM system

        Mat Tcw = SLAM.TrackMonocular(im, tframe);

        if ((Tcw.cols == 4) && (Tcw.rows == 4))
        {
            Mat Rwc = Tcw.rowRange(0, 3).colRange(0, 3).t();
            Mat Twc = -Rwc * Tcw.rowRange(0, 3).col(3);
            vector<float> q = Converter::toQuaternion(Rwc);
            // cout << "------------------" << endl;
            // cout << Twc << endl;
            CP_DATA post;
            memset(&post, 0, sizeof(CP_DATA));
            float fx = Twc.at<float>(0, 0) * 100;
            float fy = Twc.at<float>(1, 0) * 100;
            float fz = Twc.at<float>(2, 0) * 100;

            cout << "X " << fx << endl;
            cout << "Y " << fy << endl;
            cout << "Z " << fz << endl;

            post.SLAM.x = fx;
            post.SLAM.y = fy;
            post.SLAM.z = fz;

            unsigned char writeData[24] = {0};
            PosData2ArrPC(post, writeData);

            // write(livUartFd, writeData, 24);
            write(livSocketFd, writeData, 24);

            // cout << "X " << Twc.at<float>(0, 0) * 100 << endl;
            // cout << "Y " << Twc.at<float>(1, 0) * 100 << endl;
            // cout << "Z " << Twc.at<float>(2, 0) * 100 << endl;
            // QuaternionToeularangle(q[3], q[2], q[1], q[0]);
            cout << "------------------" << endl;
        }
#if CV_IMG_COUNT
#else
        imwrite(strPath.str(), im);
#endif
    }

    // Stop all threads
    SLAM.Shutdown();

    // Save camera trajectory
    // SLAM.SaveKeyFrameTrajectoryTUM("KeyFrameTrajectory.txt");

    return 0;
}

void InitUart(void)
{
    // 串口初始化
    livUartFd = app_uart_open(livUartFd, APP_UART);
    app_uart_Init(livUartFd, DEVICE_LED_UART_BAUD_RATE, 0, 8, 1, 'N');
}

void InitTCP(void)
{
    ifstream socketFile(SOCKET_FILE); 
    string strIP;
    string strPort; 
    if (!socketFile.is_open()) 
    { 
        cout << SOCKET_FILE << " open error" << endl; 
    }

    if(!getline(socketFile,strIP))
    {
        cout << SOCKET_FILE << " read error" << endl;
    }
    cout << "strIP " << strIP << endl;

    if(!getline(socketFile,strPort))
    {
        cout << SOCKET_FILE << "read error" << endl;
    }
    cout << "strPort " << strPort << endl;

    socketFile.close();

    // int
    livSocketFd = socket(AF_INET, SOCK_STREAM, 0);
    if (livSocketFd == -1)
    {
        cout << "socket create worry：" << endl;
        exit(-1);
    }
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    // addr.sin_port = htons(7777);
    // addr.sin_addr.s_addr = inet_addr("192.168.2.152");

    addr.sin_port = htons(atoi(strPort.data()));
    addr.sin_addr.s_addr = inet_addr(strIP.data());

    int res = connect(livSocketFd, (struct sockaddr *)&addr, sizeof(addr));
    if (res == -1)
    {
        cout << "bind link worry：" << endl;
        exit(-1);
    }
    cout << "bind link ok" << endl;
}

long GetCurrentTime(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}